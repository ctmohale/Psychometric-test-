<!--Update alert -->
<div class="alert alert-success text-left" role="alert" style="display: <?php echo $updateProfileSuccess; ?>">
    Profile Updated!
</div>