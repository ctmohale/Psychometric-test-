//validation proces

//A function to select all names in
function validationText(data){

    let secondaryData = document.getElementById(data);

    //All text validation
    if (!/[^a-zA-Z]/.test(secondaryData.value)){
        secondaryData.style.backgroundColor = "#ff751a";
        secondaryData.style.color = "white";
    }else{
        secondaryData.style.backgroundColor = "red";
        secondaryData.style.color = "white";
    }

}
//ID validation
function idValidation(data){

    let secondaryData = document.getElementById(data);

    if(secondaryData.value.toString().length == 13){
        secondaryData.style.backgroundColor = "#ff751a";
        secondaryData.style.color = "white";
    }else{
        secondaryData.style.backgroundColor = "red";
        secondaryData.style.color = "white";
    }

}
//Cell phone validation
function cellPhoneValidation(data){

    let secondaryData = document.getElementById(data);

    if(secondaryData.value.toString().length == 10){
        secondaryData.style.backgroundColor = "#ff751a";
        secondaryData.style.color = "white";
    }else{
        secondaryData.style.backgroundColor = "red";
        secondaryData.style.color = "white";
    }

}
//Email validation
function ValidateEmail(data) {

    let emailAdress = document.getElementById(data);
    let regexEmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (emailAdress.value.match(regexEmail)) {

        emailAdress.style.backgroundColor = "#ff751a";
        emailAdress.style.color = "white";
    } else {

        emailAdress.style.backgroundColor = "red";
        emailAdress.style.color = "white"; 
    }

}
function CheckPassword(data) { 
    let secondaryData = document.getElementById(data);
    //Check length
    if (!/[^a-zA-Z]/.test(secondaryData.value)){
        secondaryData.style.backgroundColor = "red";
        secondaryData.style.color = "white";

    }else{
        if(secondaryData.value.toString().length  >= 8){
            secondaryData.style.backgroundColor = "#ff751a";
            secondaryData.style.color = "white";
        }else{
            secondaryData.style.backgroundColor = "red";
            secondaryData.style.color = "white";
        }
    }
}  