<?php include '../php/processing.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="./assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Now UI Dashboard by Creative Tim
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <!-- CSS Files -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
  <link href="./assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="./assets/css/now-ui-dashboard.css?v=1.5.0" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="./assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
  <div class="wrapper" style="display: <?php echo $systemActive; ?>;">
    <div class="sidebar" data-color="orange">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
      <div class="logo">
        <a href="./dashboard.php" class="simple-text logo-normal">
          PSYCHOMETRIC<img src="../assets/img/Compentency.png" width="50" alt="">Test
        </a>
      </div>
      <div class="sidebar-wrapper" id="sidebar-wrapper">
        <ul class="nav">
          <li class="active ">
            <a href="./dashboard.php">
              <i class="fas fa-tachometer-alt"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li>
            <a href="./users.php">
              <i class="fas fa-users"></i>
              <p>Users</p>
            </a>
          </li>
          <li>
            <a type="button" data-bs-toggle="modal" data-bs-target="#questions">
              <i class="fas fa-question-circle"></i>
              <p>Questions</p>
            </a>
          </li>
          <li>
            <a type="button" data-bs-toggle="modal" data-bs-target="#userProfile">
              <i class="fas fa-user-cog"></i>
              <p>User Profile</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel" id="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent  bg-primary  navbar-absolute">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <a class="navbar-brand" href="#pablo">Dashboard</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navigation">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="../index.php?logout=true">
                  <i class="fas fa-sign-out-alt fa-2x"></i>
                  <p>
                    <span class="d-lg-none d-md-block">Account</span>
                  </p>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="panel-header panel-header-lg" style="min-height: 600px; overflow-y: scroll;">

        <div class="row" style="margin: 2%;">
        <div class="alert alert-danger" role="alert" style="display: <?php echo $adminDeleteRecordAlert; ?>;">
          Record updated!
        </div>
        <div class="alert alert-primary" role="alert" style="display: <?php echo $addQuestionAlert; ?>;">
          Question added successfully!
        </div>
        <div class="alert alert-primary" role="alert" style="display: <?php echo $alertAdminInfoUpdate; ?>;">
          Admin updated successfully!
        </div>
          <div class="col-sm-3">
            <div class="card" style="border-radius: 10px;">
              <div class="card-body text-center"  style="padding-top: 20% !important; padding-bottom: 20% !important;">
              <img src="../assets/img/undraw_Add_user_re_5oib.png" width="300" alt="">
                <h5 class="card-title">Total users</h5>
                <h1 class="text-primary"><?php echo mainCountStat($conn,'user','','','',''); ?></h1>
                <p class="card-text">Registerd</p>
              </div>
            </div>
          </div>
          <div class="col-sm-3">
            <div class="card" style="border-radius: 10px;">
              <div class="card-body text-center"  style="padding-top: 20% !important; padding-bottom: 20% !important;">
                <img src="../assets/img/undraw_pending_approval_xuu9.png" width="170" alt="">
                <h5 class="card-title">Total Questions</h5>
                <h1 class="text-primary"><?php echo mainCountStat($conn,'question','','','',''); ?></h1>
                <p class="card-text">Personality Questions</p>
              </div>
            </div>
          </div>
          <div class="col-sm-3">
            <div class="card" style="border-radius: 10px;">
              <div class="card-body text-center"  style="padding-top: 20% !important; padding-bottom: 20% !important;">
              <img src="../assets/img/undraw_exams_g4ow.png" width="180" alt="">
                <h5 class="card-title">Total test</h5>
                <h1 class="text-primary">10</h1>
                <p class="card-text">Written text total</p>
              </div>
            </div>
          </div>
          <div class="col-sm-3">
            <div class="card" style="border-radius: 10px;">
              <div class="card-body text-center"  style="padding-top: 20% !important; padding-bottom: 20% !important;">
                <img src="../assets/img/undraw_Security_on_re_e491.png" width="600" alt="">
                <h5 class="card-title">Admin info</h5>
                <p class="text-primary"><i class="fas fa-envelope"></i> <?php echo selectAllData($conn,'admin','UserName','UserName',$_SESSION['emailAdmin']); ?></p>
                <p class="card-text pt-5">Secured</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <footer class="footer">
        <div class=" container-fluid ">
          <nav>
            <ul>
              <li>
                <a href="./dashboard.php">
                  Home
                </a>
              </li>
            </ul>
          </nav>
          <div class="copyright" id="copyright">
            &copy; <script>
              document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))
            </script> <i class="fas fa-user-cog text-secondary fa-2x"></i>
          </div>
        </div>
      </footer>
    </div>
  </div>
  <section style="margin: 5%; padding: 10%; display: <?php echo $displaySessionOver; ?>;">
    <div class="card text-center bg-primary" style="padding: 10%">
      <h1 class="text-light">SESSION OVER!</h1>
      <hr>
      <a class="text-light" href="../index.php">Home</a>
    </div>
  </section>
  <!-- Modal User data -->
  <div class="modal fade" id="users" tabindex="-1" aria-labelledby="usersLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="usersLabel"><i class="fas fa-users"></i>Users</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="col-md-12">
            <div class="card card-plain">
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                      <th>
                        ID
                      </th>
                      <th>
                        Name
                      </th>
                      <th>
                        Surname
                      </th>
                      <th>
                        Test Status
                      </th>
                      <th class="text-center">
                        Open
                      </th>
                      <th class="text-right text-center">
                        Delete
                      </th>
                    </thead>
                    <tbody>
                      <?php while($row = $resultUsers->fetch_assoc()): ?>
                      <tr>
                        <td>
                          <?php echo $row['Id']; ?>
                        </td>
                        <td>
                          <?php echo $row['Name']; ?>
                        </td>
                        <td>
                          <?php echo $row['Surname']; ?>
                        </td>
                        <td>
                          <?php echo $row['Name']; ?>
                        </td>
                        <td class="text-center">
                          <a href="./user-records.php?userID=<?php echo $row['Id']; ?>"><i class="fas fa-folder-open fa-2x"></i></a>
                        </td>
                        <td class="text-right text-center">
                         <a href=""><i class="fas fa-trash fa-2x text-danger"></i></a>
                        </td>
                      </tr>
                      <?php endwhile; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal Questions -->
  <div class="modal fade" id="questions" tabindex="-1" aria-labelledby="questionsLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="questionsLabel"><i class="fas fa-questions"></i>Questions</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-sm-8">
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table">
                      <thead class=" text-primary">
                        <th>
                          ID
                        </th>
                        <th>
                          Question
                        </th>
                        <th>
                          Personality
                        </th>
                        <th class="text-right text-center">
                          Delete
                        </th>
                      </thead>
                      <tbody>
                      <?php while($row = $resultSelectAllQuestions->fetch_assoc()): ?>
                        <tr>
                          <td>
                            <?php echo $row['Id']; ?>
                          </td>
                          <td>
                            <?php echo $row['Qns']; ?>
                          </td>
                          <td>
                            <?php echo $row['Personality']; ?>
                          </td>
                          <td class="text-right text-center">
                           <a href="./dashboard.php?deleteQuestion=<?php echo $row['Id']; ?>"><i class="fas fa-trash fa-2x text-danger"></i></a>
                          </td>
                        </tr>
                        <?php endwhile; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
            </div>
            <div class="col-sm-4">
              <div class="card" style="border-radius: 20px; border-left: 3px solid rgba(255, 81, 0, 0.719);">
                <div class="card-body text-center">
                  <br>
                  <br>
                  <br>
                  <img src="../assets/img/undraw_pending_approval_xuu9.png" width="100%" alt=""><br>
                  <a data-bs-toggle="modal" data-bs-target="#addQuestion" type="button" class="btn btn-primary" style="border-radius: 100px; color: white;">Add Questions</a>
                  <br>
                  <br>
                  <br>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal Questions ADD MORE -->
  <div class="modal fade" id="addQuestion" tabindex="-1" aria-labelledby="addQuestionLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="addQuestionLabel"><i class="fas fa-addQuestion"></i>Users</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
        <form method="post">
          <div class="row">
            <div class="col-sm-8">
                <div class="card-body">
                  
                    <div>
                      <select name="penso" class="form-select" aria-label="Default select example">
                        <option selected>Select personality</option>
                        <option value="Openness">Openness</option>
                        <option value="Conscientiousness">Conscientiousness</option>
                        <option value="Agreeable">Agreeable</option>
                        <option value="Extroversion">Extroversion</option>
                        <option value="Neuroticism">Neuroticism</option>
                      </select>
                      </select>
                    </div>
                    <div>
                    <div class="mb-3">
                      <br>
                      <label for="exampleFormControlTextarea1" class="form-label"> Add a question?</label>
                      <textarea class="form-control" name="question" rows="2" required></textarea>
                    </div>
                    </div>
                 
                </div>
            </div>
            <div class="col-sm-4">
              <div class="card" style="border-radius: 20px; border-left: 3px solid rgba(255, 81, 0, 0.719);">
                <div class="card-body text-center">
                  <br>
                  <br>
                  <br>
                  <i class="fas fa-question-circle fa-6x"></i><br>
                  <button  type="submit" name="btnAddQuestion" class="btn btn-primary" style="border-radius: 100px; color: white;">Add Questions</button>
                  <br>
                  <br>
                  <br>
                </div>
              </div>
            </div>
          </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal User results -->
  <div class="modal fade" id="userResults" tabindex="-1" aria-labelledby="userResultsLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="userResultsLabel"><i class="fas fa-user-check"></i> Users Results</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-sm-8">
              <div class="table-responsive">
                <table class="table">
                  <thead class=" text-primary">
                    <th>
                      ID
                    </th>
                    <th>
                      Name
                    </th>
                    <th>
                      Surname
                    </th>
                    <th class="text-center">
                      Open results
                    </th>
                    <th class="text-right text-center">
                      Delete
                    </th>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        1
                      </td>
                      <td>
                        Chris
                      </td>
                      <td>
                        Mohale
                      </td>
                      <td class="text-right text-center">
                        <a href=""><i class="fas fa-folder-open fa-2x"></i></i></a>
                       </td>
                      <td class="text-right text-center">
                       <a href=""><i class="fas fa-trash fa-2x text-danger"></i></a>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="col-sm-4">
              <div class="card" style="border-radius: 20px; border-left: 3px solid rgba(255, 81, 0, 0.719);">
                <div class="card-body text-center">
                  <br>
                  <br>
                  <br>
                  <img src="../assets/img/mission.png" width="50%" alt="">
                  <br>
                  <br>
                  <br>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
    <!-- Modal User results -->
    <div class="modal fade" id="userResults" tabindex="-1" aria-labelledby="userResultsLabel" aria-hidden="true">
      <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="userResultsLabel"><i class="fas fa-user-check"></i> Users Results</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="row">
              <div class="col-sm-8">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                      <th>
                        ID
                      </th>
                      <th>
                        Name
                      </th>
                      <th>
                        Surname
                      </th>
                      <th class="text-center">
                        Open results
                      </th>
                      <th class="text-right text-center">
                        Delete
                      </th>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          1
                        </td>
                        <td>
                          Chris
                        </td>
                        <td>
                          Mohale
                        </td>
                        <td class="text-right text-center">
                          <a href=""><i class="fas fa-folder-open fa-2x"></i></i></a>
                         </td>
                        <td class="text-right text-center">
                         <a href=""><i class="fas fa-trash fa-2x text-danger"></i></a>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="col-sm-4">
                <div class="card" style="border-radius: 20px; border-left: 3px solid rgba(255, 81, 0, 0.719);">
                  <div class="card-body text-center">
                    <br>
                    <br>
                    <br>
                    <img src="../assets/img/mission.png" width="50%" alt="">
                    <br>
                    <br>
                    <br>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>  
  <!-- Modal User Profile -->
  <div class="modal fade" id="userProfile" tabindex="-1" aria-labelledby="userProfileLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="userProfileLabel"><i class="fas fa-user-check"></i> Users Profile</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-sm-6">
              <form method="POST">
              <div class="text-center">
              <br>
              <br>
              <h3>Admin Profile</h3>
              </div>
                <div class="row" style="padding:5%;">
                    <div class="form-group">
                      <label>Admin email</label>
                      <input name="email" type="email" class="form-control" placeholder="Email" value="<?php echo selectAllData($conn,'admin','UserName','UserName',$_SESSION['emailAdmin']); ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Admin password</label>
                      <input name="password" type="password" class="form-control" placeholder="Password" value="<?php echo selectAllData($conn,'admin','Password','UserName',$_SESSION['emailAdmin']); ?>">
                    </div>
                    <div class="text-center">
                        <button name="btnUpdateAdmin" class="btn btn-primary" style="border-radius: 20px;">Update Info</button>
                    </div>
                </div>
              </form>
            </div>
            <div class="col-sm-6">
              <div class="card" style="border-radius: 20px; border-left: 3px solid rgba(255, 81, 0, 0.719);">
                <div class="card-body text-center">
                  <br>
                  <br>
                  <img src="../assets/img/undraw_Security_on_re_e491.png" width="100%" alt="">
                  <br>
                  <br>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="./assets/js/core/jquery.min.js"></script>
  <script src="./assets/js/core/popper.min.js"></script>
  <script src="./assets/js/core/bootstrap.min.js"></script>
  <script src="./assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chart JS -->
  <script src="./assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="./assets/js/plugins/bootstrap-notify.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="./assets/js/now-ui-dashboard.min.js?v=1.5.0" type="text/javascript"></script><!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
  <script src="./assets/demo/demo.js"></script>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      demo.initDashboardPageCharts();

    });
  </script>
</body>

</html>