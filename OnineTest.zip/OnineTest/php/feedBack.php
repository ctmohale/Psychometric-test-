<?php 
    //Displays password error
    if(isset($_GET['password'])){
        if('error' == decodeUrl($_GET['password'])){
            $passwordError = "";
        }
    }
    //Displays email error
    if(isset($_GET['email'])){
        if('error' == decodeUrl($_GET['email'])){
            $emailError = "";
        }
    }