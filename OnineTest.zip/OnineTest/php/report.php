<?php
include 'processing.php';
require('../fpdf/fpdf.php');

class PDF extends FPDF
{
    function hader($perso, $scor,$mainPer, $name, $surname )
    {
        $this->SetFont('Arial', 'B', 14);
        $this->Cell(276, 5, 'PSYCHOMETRIC TEST FOR', 0, 0, 'C');
        $this->Ln(5);
        $this->SetFont('Arial', 'B', 13);
        $this->Cell(276, 10, $surname . ' ' . $name, 0, 0, 'C');
        $this->Ln();
        $this->SetFont('Times', '', 12);
        $this->Cell(276, 10, 'Personality results? ', 0, 0, 'C');
        $this->Ln(20);
        $this->Cell(276, 10, 'TOTAL SCORE : ' . $perso, 0, 0, 'L');
        $this->Ln(5);
        $this->SetFont('Arial', 'B', 13);
        $this->Cell(276, 10, $scor . '%', 0, 0, 'L');
        $this->Ln(5);
        $this->SetFont('Times', '', 12);
        $this->Cell(276, 10, $mainPer, 0, 0, 'L');
        $this->Ln(5);
        $this->Cell(276, 10, '_________________________________________', 0, 0, 'L');
        $this->Ln(20);
    }
    function lowerSection($A, $B)
    {
        $this->Ln(8);
        $this->SetFont('Arial', 'B', 13);
        $this->Cell(276, 10, "Careers" . '%', 0, 0, 'L');
        $this->Ln(8);
        foreach ($A as $B){
            $this->SetFont('Times', '', 12);
            $this->Cell(276, 10, $B, 0, 0, 'L');
            $this->Ln(5);
        }
        $this->Cell(276, 10, '_________________________________________', 0, 0, 'L');
        $this->Ln(20);
    }
    function footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', '', 8);
        //$this->Cell(0, 10, 'Page'.this->PageNo().'/{nb}',0,0, 'C');
    }
    function headerTable()
    {
        $this->SetFont('Times', 'B', 12);
        $this->Cell(30, 10, 'Oppenness', 1, 0, 'C');
        $this->Cell(60, 10, 'Conscientiousness', 1, 0, 'C');
        $this->Cell(60, 10, 'Agreeable', 1, 0, 'C');
        $this->Cell(60, 10, 'Extroversion', 1, 0, 'C');
        $this->Cell(70, 10, 'Neuroticism', 1, 0, 'C');
        $this->Ln();
    }
    function dataFromDb($A,$B,$C,$D,$E)
    {
        $this->SetFont('Times', '', 12);
        $this->SetFont('Times', 'B', 12);
        $this->Cell(30, 10, $A . "%", 1, 0, 'C');
        $this->Cell(60, 10, $B . "%", 1, 0, 'C');
        $this->Cell(60, 10, $C . "%", 1, 0, 'C');
        $this->Cell(60, 10, $D . "%", 1, 0, 'C');
        $this->Cell(70, 10, $E . "%", 1, 0, 'C');
        $this->Ln();
   
    }
}
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage('L', 'A4', 0);
$pdf->hader($PersonalityScore, $TotalScore, $PersonalityScoreMoreData, selectAllData($conn,'user','Name','UserName',$_SESSION['email']), selectAllData($conn,'user','Surname','UserName',$_SESSION['email']));
$pdf->headerTable();
$pdf->dataFromDb($OppennessPecentage,$ConscientiousnessPecentage,$ConscientiousnessPecentage,$ExtroversionPecentage,$NeuroticismPecentage);
$pdf->lowerSection($CareersPersonality,"B");
$pdf->Output();