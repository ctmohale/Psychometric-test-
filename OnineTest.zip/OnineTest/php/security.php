<?php
//_______________________________________________________________________
//This function encode the url string
function incodeUrl($urlData){
    return base64_encode($urlData);
}

//_______________________________________________________________________
//This function encode the url string
function decodeUrl($urlData){
    return base64_decode($urlData);
}