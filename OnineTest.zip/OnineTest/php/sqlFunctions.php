<?php 
    @session_start();
    //_________________________________________________________________
    //Link to all the external sscript
    include 'variable.php';


     //----------------------------------------------------------------------------------------------
    //All the sql functions (Global select function)
    function selectAllData($conn,$tableName,$dataToSelect,$dataSelectedIdOnTable,$dataSelectId){

        $sql = "SELECT $dataToSelect FROM $tableName WHERE $dataSelectedIdOnTable = '$dataSelectId'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                return $row[$dataToSelect];
            }
        } else {
            return false;
        }
    }
    //----------------------------------------------------------------------------------------------
    //Update any type of data in the tables
    function insertUsers($conn, $Name, $Surname, $Id_no, $Cell_No, $Email, $Password, $Branch){
        //Variable
        $Gender = "";
        //Get Gender from an id number 
        if(intval(substr($Id_no,6,1)) < 5){ $Gender = "Female";} else{ $Gender = "Male"; }

        $sql = "INSERT INTO user (Name, Surname, IdNo, phNo, UserName, Password, Branch, Gender, rollNo)
        VALUES ('$Name', '$Surname', '$Id_no', '$Cell_No', '$Email','$Password', '$Branch','$Gender', 'ok')";
        
        if ($conn->query($sql) === TRUE) { 
            return true;
        } else {
          return "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    //----------------------------------------------------------------------------------------------
    //Update any type of data in the tables
    function insertAnswers($conn, $QuestionId, $Answer, $Correction, $Email){

        $sql = "INSERT INTO useranswer (Qid, Ans, Correction, Username)
        VALUES ('$QuestionId', '$Answer', '$Correction', '$Email')";
        
        if ($conn->query($sql) === TRUE) { 
            return true;
        } else {
            return "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    function insertQuestions($conn, $Question, $Personality){

        $sql = "INSERT INTO question (Qns, Personality)
        VALUES ('$Question', '$Personality')";
        
        if ($conn->query($sql) === TRUE) { 
            return true;
        } else {
            return "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    //----------------------------------------------------------------------------------------------
    //Update any type of data in the tables
    function updateFunction($conn, $tableName, $selectedFiled, $updateData, $selectedFiledForId, $filedId){
        $sql = "UPDATE $tableName SET $selectedFiled = '$updateData' WHERE $selectedFiledForId = '$filedId' ";

        if ($conn->query($sql) === TRUE) {
            return true;
        } else {
            return false;
        }
    }
    //----------------------------------------------------------------------------------------------
    //This function counts and return the total count
    function mainCountStats($conn,$tableName, $dataSelected,$dataSelected_Clues, $dataSelectedId, $dataSelectedId_Clues){

        //Set the counter
        $countData = 0;
        $sql = "";
        if($dataSelected_Clues != ''){
            $sql = "SELECT * FROM $tableName WHERE $dataSelected = '$dataSelectedId' AND $dataSelected_Clues = '$dataSelectedId_Clues'";
        }
        else{
            $sql = "SELECT * FROM $tableName WHERE $dataSelected = '$dataSelectedId'";
        }
        
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
          // output data of each row
          while($row = $result->fetch_assoc()) {
            $countData++;
          }
        } else {
            $countData = 0;
        }
        //Return the counter value
        return $countData;
    }
     //----------------------------------------------------------------------------------------------
    //Delete function
    function daleteFunction($conn,$tableName,$selectedRecord,$recordId){
        $sql = "DELETE FROM $tableName WHERE $selectedRecord = $recordId";

        if ($conn->query($sql) === TRUE) {
            return true;
        } else {
            return false;
        }
    }

    //This function counts and return the total count
    function mainCountStat($conn,$tableName, $dataSelected,$dataSelected_Clues, $dataSelectedId, $dataSelectedId_Clues){

        //Set the counter
        $countData = 0;
        $sql = "";
        if($dataSelected_Clues != ''){
            $sql = "SELECT * FROM $tableName WHERE $dataSelected = '$dataSelectedId' AND $dataSelected_Clues = '$dataSelectedId_Clues'";
        }
        else if($dataSelected_Clues == '' && $dataSelected == ''){
            $sql = "SELECT * FROM $tableName ";
        }else{
            $sql = "SELECT * FROM $tableName WHERE $dataSelected = '$dataSelectedId'";
        }
        
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
          // output data of each row
          while($row = $result->fetch_assoc()) {
            $countData++;
          }
        } else {
            $countData = 0;
        }
        //Return the counter value
        return $countData;
    }

    //----------------------------------Manual Selection of Data-------------------------------------------------
    //Select questions function
    $sqlSelectAllQuestions = "SELECT * FROM question ORDER BY Id DESC";
    $resultQuestions = $conn->query($sqlSelectAllQuestions);

    $sqlSelectAllUsers = "SELECT * FROM user ORDER BY Id DESC";
    $resultUsers = $conn->query($sqlSelectAllUsers);

    $sqlSelectAllQuestions = "SELECT * FROM question ORDER BY Id DESC";
    $resultSelectAllQuestions = $conn->query($sqlSelectAllQuestions);
  
    //Select Ansewrs Oppenness function
    if(isset($_SESSION['email'])){

        $sqlSelectAnswersPersonality = "SELECT * FROM useranswer  WHERE Username = '$_SESSION[email]'";
        $resultAnswersPersonality = $conn->query($sqlSelectAnswersPersonality);
    }