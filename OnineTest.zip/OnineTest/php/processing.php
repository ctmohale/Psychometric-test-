<?php
@session_start();

//_________________________________________________________________
//Link to all the external sscript
include 'connect.php';
include 'sqlFunctions.php';
include 'security.php';
include 'variable.php';

//__________________________________________________________________
//Login section
//Check if the email exist first
if(isset($_POST['loginBtnUser'])){

    if(selectAllData($conn,'user','UserName','UserName',$_POST['email']) == $_POST['email']){

        //Check if the password exist
        if(selectAllData($conn,'user','Password','Password',$_POST['password']) == $_POST['password']){
            //The log the admin in
    
            //set all session to be active
            $_SESSION['email'] = $_POST['email'];
    
            //Direct admin to the dashbord
            header('Location:./index.php');
        }
        else{
            //Direct to the login page with password error 
            header('Location:index.php?password=error');
            //exit();
        }
    
    }else{

        if(selectAllData($conn,'admin','UserName','UserName',$_POST['email']) == $_POST['email']){
            if(selectAllData($conn,'admin','Password','Password',$_POST['password']) == $_POST['password']){
                $_SESSION['emailAdmin'] = $_POST['email'];
                header('Location:./admin/dashboard.php');
            }else{
                header('Location:index.php?password=error');
            }
        }else{
            header('Location:index.php?email=error');
            //exit();
        }

    }
}
if(isset($_GET['password'])){
  
    if($_GET['password'] == 'error'){
        $alertPassError = "";
    }
}
if(isset($_GET['email'])){
    if($_GET['email'] == 'error'){
        $alertEmailError = "";
    }
}
//_________________________________________________________Admin in __________________________________________________________________
if(isset($_SESSION['emailAdmin'])){
    //All all actions are
    $systemActive = "";
    if(isset($_POST['btnUpdateUsers'])){
        //updateFunction($conn, $tableName, $selectedFiled, $updateData, $selectedFiledForId, $filedId)
        updateFunction($conn,'user','Name',$_POST['name'],'Id', $_GET['userID']);
        updateFunction($conn,'user','Surname',$_POST['surname'],'Id', $_GET['userID']);
        updateFunction($conn,'user','IdNo',$_POST['id_No'],'Id', $_GET['userID']);

        //Check gender first
        if(isset($_POST['id_No'])){
            $Gender = "";
            //Get Gender from an id number 
            
            if(intval(substr($_POST['id_No'],6,1)) < 5){ $Gender = "Female";} else{ $Gender = "Male"; }
            updateFunction($conn,'user','Gender',$Gender,'Id', $_GET['userID']);  
        } 

        updateFunction($conn,'user','phNo',$_POST['cell_No'],'Id', $_GET['userID']);
        updateFunction($conn,'user','UserName',$_POST['email'],'Id', $_GET['userID']);
        updateFunction($conn,'user','Branch',$_POST['branch'],'Id', $_GET['userID']);
        $adminUpdateRecordAlert = "";
    }
    //delete
    if(isset($_POST['btnDeleteUsers'])){
        if(daleteFunction($conn,'user','Id',$_GET['userID']) == true){
            header('Location:./dashboard.php?deleteUser=ok');
        }
    }
    if(isset($_GET['deleteUser'])){
        $adminDeleteRecordAlert = "";
    }
    //Delete Questions
    if(isset($_GET['deleteQuestion'])){
        if(daleteFunction($conn,'question','Id',$_GET['deleteQuestion']) == true){
            header('Location:./dashboard.php?deleteQuestion=ok');
        }
    }
    if(isset($_GET['deleteQuestion'])){
        $adminDeleteRecordAlert = "";
    }
    //____________________Add questions___________________________________
    if(isset($_POST['btnAddQuestion'])){
        if(insertQuestions($conn,$_POST['question'],$_POST['penso']) == true){
            header('Location:./dashboard.php?addQuestion=ok');
        }
    }
    if(isset($_GET['addQuestion'])){
        $addQuestionAlert = "";
    }
    //__________________________Access the user results in__________________________________________
    if(isset($_GET['userResultsId'])){
        $_SESSION['userResultsId'] = $_GET['userResultsId'];
        $_SESSION['email'] = selectAllData($conn,'user','UserName','Id',$_GET['userResultsId']);
        header('Location:./user-results.php');
    }
    if(isset($_SESSION['userResultsId'])){
        
        //Check if results exist exist
        if(selectAllData($conn,'user','UserName','Id',$_SESSION['userResultsId']) == selectAllData($conn,'useranswer','Username','Username',selectAllData($conn,'user','UserName','Id',$_SESSION['userResultsId']))){
            
            $displayAdminUserResults = "";
        }else{
            $displayAdminUserResultsNone = "";
        }

    }
    
    //________________________________Update admin user
    if(isset($_POST['btnUpdateAdmin'])){


        if(updateFunction($conn,'admin','Password',$_POST['password'],'UserName', $_SESSION['emailAdmin']) == true){
            
            updateFunction($conn,'admin','UserName',$_POST['email'],'UserName', $_SESSION['emailAdmin']);
            $_SESSION['emailAdmin'] = $_POST['email'];
            header('Location:./dashboard.php?admin=true');
        }
    }
    if(isset($_GET['admin'])){
        $alertAdminInfoUpdate = "";
    }


}else{
    $displaySessionOver = "";
}

//__________________________________________________________________
//Loggged in to system domain
if(isset($_SESSION['email'])){

    //Update user profile
    if(isset($_POST['btnUpdateUser'])){

        //updateFunction($conn, $tableName, $selectedFiled, $updateData, $selectedFiledForId, $filedId)
        updateFunction($conn,'user','Name',$_POST['name'],'UserName', $_SESSION['email']);
        updateFunction($conn,'user','Surname',$_POST['surname'],'UserName', $_SESSION['email']);
        updateFunction($conn,'user','IdNo',$_POST['id_No'],'UserName', $_SESSION['email']);

        //Check gender first
        if(isset($_POST['id_No'])){
            $Gender = "";

            //Get Gender from an id number 
            if(intval(substr($_POST['id_No'],6,1)) < 5){ $Gender = "Female";} else{ $Gender = "Male"; }
            updateFunction($conn,'user','Gender',$Gender,'UserName', $_SESSION['email']);   
        }
        updateFunction($conn,'user','phNo',$_POST['cell_No'],'UserName', $_SESSION['email']);
        updateFunction($conn,'user','UserName',$_POST['email'],'UserName', $_SESSION['email']);
        updateFunction($conn,'user','Password',$_POST['password'],'UserName', $_SESSION['email']);
        updateFunction($conn,'user','Branch',$_POST['branch'],'UserName', $_SESSION['email']);
        $updateProfileSuccess = "";
        $alertUserUpdated = "";

    }
    //Answer checking function
    if(isset($_POST['btnSubmitAnsers'])){

        while($row = $resultQuestions->fetch_assoc()){

            if(isset($_POST['Question'.$row['Id']])){
                //echo $_POST['Question'.$row['Id']] . $row['Id'] . "<br/>";
              if(insertAnswers($conn,$row['Id'],$_POST['Question'.$row['Id']],"None",$_SESSION['email']) == true){
                  header("Location:test-page.php?testSatus=Complete");
              }
            }
        }
    }
    if(isset($_GET['testSatus'])){
        if($_GET['testSatus'] == 'Complete'){
            $testDivHide = "";
            $testDivShow = "none";
        }
    }

    //___________________________________Results Processing section_____________________________

    if ($resultAnswersPersonality->num_rows > 0) {
        // output data of each row
        while($row = $resultAnswersPersonality->fetch_assoc()) {
            //Opennness answers
            if(selectAllData($conn,'question','Personality','Id',$row['Qid']) == "Openness")
            {
                //Total number of openness questions
                $OppennessTotalCount++;

                if($row['Ans'] == "Agree"){

                    //Total number of openness Agree questions
                    $OppennessCount++;
                }
            }
            //Conscientiousness answers
            if(selectAllData($conn,'question','Personality','Id',$row['Qid']) == "Conscientiousness")
            {
                //Total number of Conscientiousness questions
                $ConscientiousnessTotalCount++;

                if($row['Ans'] == "Agree"){

                    //Total number of Conscientiousness Agree questions
                    $ConscientiousnessCount++;
                }
            }
            //Agreeable answers
            if(selectAllData($conn,'question','Personality','Id',$row['Qid']) == "Agreeable")
            {
                //Total number of Agreeable questions
                $AgreeableTotalCount++;

                if($row['Ans'] == "Agree"){

                    //Total number of Agreeable Agree questions
                    $AgreeableCount++;
                }
            }
            //Extroversion answers
            if(selectAllData($conn,'question','Personality','Id',$row['Qid']) == "Extroversion")
            {
                //Total number of Agreeable questions
                $ExtroversionTotalCount++;

                if($row['Ans'] == "Agree"){

                    //Total number of Agreeable Agree questions
                    $ExtroversionCount++;
                }
            }
            //Neuroticism answers
            if(selectAllData($conn,'question','Personality','Id',$row['Qid']) == "Neuroticism")
            {
                //Total number of Agreeable questions
                $NeuroticismTotalCount++;

                if($row['Ans'] == "Agree"){

                    //Total number of Agreeable Agree questions
                    $NeuroticismCount++;
                }
            }
            
        }
    } else {
        //echo "0 results";
    }

    
    //Calculated percentage of oppennness results
    if($OppennessTotalCount == 0){
        $OppennessPecentag = 0;
    }else{
        $OppennessPecentage = round(($OppennessCount / $OppennessTotalCount) * 100);
    }

    //Calculated percentage of Conscientiousness results
    if($ConscientiousnessTotalCount == 0){
        $ConscientiousnessPecentage = 0;
    }else{
        $ConscientiousnessPecentage = round(($ConscientiousnessCount / $ConscientiousnessTotalCount) * 100);
    }

    //Calculated percentage of Conscientiousness results
    if($AgreeableTotalCount == 0){
        $AgreeablePecentage = 0;
    }else{
        $AgreeablePecentage = round(($AgreeableCount / $AgreeableTotalCount) * 100);
    }

    //Calculated percentage of Conscientiousness results
    if($ExtroversionTotalCount ==0){
        $ExtroversionPecentage = 0;
    }else{
        $ExtroversionPecentage = round(($ExtroversionCount / $ExtroversionTotalCount) * 100);
    }

    //Calculated percentage of Conscientiousness results
    if($NeuroticismTotalCount == 0){
        $NeuroticismPecentage = 0;
    }else{
        $NeuroticismPecentage = round(($NeuroticismCount / $NeuroticismTotalCount) * 100);
    }

    //Laying  down all the results to
    $TotalScore =  max($OppennessPecentage,$ConscientiousnessPecentage,$AgreeablePecentage,$ExtroversionPecentage,$ExtroversionPecentage,$NeuroticismPecentage);
    if(max($OppennessPecentage,$ConscientiousnessPecentage,$AgreeablePecentage,$ExtroversionPecentage,$ExtroversionPecentage,$NeuroticismPecentage) == $OppennessPecentage){
        $PersonalityScore = "Oppenness";
        $PersonalityScoreMoreData = "You are Adventurous, Creative, Enjoy new experience";
        $CareersPersonality = array('Politician','Doctor','Business owner','Writer','Psychologist','Nurse', 'Social Work');

        $CareerTitleA = "Law";
        $UniveristyLinkA = array('<a href="https://www.up.ac.za/"> University of Pretoria </a>', '<a href="http://www.students.uct.ac.za/"> University of Cape Town  </a>', '<a href="http://www.sun.ac.za/"> Stellenbosch University </a>', '<a href="https://www.univen.ac.za/"> University of Venda  </a>', '<a href="http://www.uj.ac.za/"> University of Johannesburg  </a>');
        
        $CareerTitleB = "Entrepreneur";
        $UniveristyLinkB = array('<a href="http://www.students.uct.ac.za/"> University of Cape Town  </a>', '<a href="http://www.sun.ac.za/"> Stellenbosch University  </a>', '<a href="http://www.ul.ac.za/"> University of Limpopo </a>', '<a href="http://www.unisa.ac.za/"> University of South Africa  </a>', '<a href="http://www.uj.ac.za/"> University of Johannesburg  </a>');

        $CareerTitleC = "Pilot";
        $UniveristyLinkC = array('<a href="http://www.cape-town-flying.co.za/"> CapeTown Flight Centre  </a>', '<a href="http://www.durbanaviationcentre.com/"> Durban Aviation Centre</a>', '<a href="http://www.avconjet.co.za/"> Avcon Jet Africa  </a>', '<a href="http://www.cfasa.co.za/"> Central Flying Academy  </a>', '<a href="http://www.jsf.co.za/"> Johannesburg School of flying  </a>');

    }
    else if(max($OppennessPecentage,$ConscientiousnessPecentage,$AgreeablePecentage,$ExtroversionPecentage,$ExtroversionPecentage,$NeuroticismPecentage) == $ConscientiousnessPecentage){
        $PersonalityScore = "Conscientiousness";
        $PersonalityScoreMoreData = "You Spend time preparing, Organized, Pay attention to details";
        $CareersPersonality = array('Politician','Doctor','Business owner','Writer','Psychologist','Nurse', 'Social Work');

        $CareerTitleA = "Doctor";
        $UniveristyLinkA = array('<a href="http://www.students.uct.ac.za/"> University of Cape Town  </a> ','<a href="https://www.wits.ac.za/"> University of Witwatersrand  </a> ','<a href="http://www.sun.ac.za/"> Stellenbosch University </a> ','<a href="https://www.ukzn.ac.za/"> University of KwaZulu-Natal  </a> ','<a href="http://www.up.ac.za/"> University of Pretoria </a> ','<a href="http://www.nwu.ac.za/"> Northwest University  </a> ','<a href="http://www.smu.ac.za/"> Sefako Makgatho Health Sciences University  </a> ','<a href="http://www.ufs.ac.za/"> University of the Free State  </a> ','<a href="http://www.ul.ac.za/"> University of Limpopo  </a> ','<a href="http://www.wsu.ac.za/"> Walter Sisulu University  </a> ', '<a href="http://www.uj.ac.za/"> University of Johannesburg  </a> ', '<a href="http://www.uwc.ac.za/"> University of Western Cape </a> ');
        
        $CareerTitleB = "Nurse";
        $UniveristyLinkB = array('<a href="https://www.wits.ac.za/"> University of Witwatersrand  </a> ','<a href="http://www.students.uct.ac.za/"> University of Cape Town  </a> ','<a href="https://www.up.ac.za/"> University of Pretoria </a> ','<a href="https://www.tut.ac.za/"> Tshwane University of Technology  </a> ','<a href="https://www.vut.ac.za/"> Vaal University of Technology  </a> ','<a href="https://www.cput.ac.za/"> Cape Peninsula University of Technology </a> ','<a href="https://www.ufh.ac.za/"> University of Fort Hare </a> ','<a href="https://www.chrishanibaragwanathhospital.co.za/departments/nursing_college/"> Baragwanath Nursing College </a> ','<a href="https://www.dut.ac.za/"> Durban University of Technology  </a> ');

        $CareerTitleC = "Psychology";
        $UniveristyLinkC = array('<a href="https://www.sacap.edu.za/"> South African College of Applied Psychology </a> ','<a href="http://www.uj.ac.za/"> University of Johannesburg  </a> ','<a href="http://www.sun.ac.za/"> Stellenbosch University  </a> ','<a href="http://www.uct.ac.za/"> University of Cape Town  </a> ','<a href="http://www.ru.ac.za/"> Rhodes University  </a> ','<a href="http://www.wits.ac.za/"> University of Witwatersrand  </a> ','<a href="http://www.up.ac.za/"> University of Pretoria  </a> ');
    }
    else if(max($OppennessPecentage,$ConscientiousnessPecentage,$AgreeablePecentage,$ExtroversionPecentage,$ExtroversionPecentage,$NeuroticismPecentage) == $AgreeablePecentage){
        $PersonalityScore = "Agreeable";
        $PersonalityScoreMoreData = "You are Trusting, Affectionate and Kind";
        $CareersPersonality = array('Counselor','Nurse','Teacher','Judge','Psychologist');

        $CareerTitleA = "Counselling";
        $UniveristyLinkA = array('<a href="http://www.wits.ac.za/"> University of Witwatersrand </a> ','<a href="http://www.up.ac.za/"> University of Pretoria  </a> ','<a href="http://www.uct.ac.za/"> University of Cape Town  </a> ','<a href="http://www.sun.ac.za/"> UNIVERSITY OF STELLENBOSCH  </a> ');
        
        $CareerTitleB = "Teacher";
        $UniveristyLinkB = array('<a href="http://www.uj.ac.za/"> UNIVERSITY OF JOHANNESBURG </a> ','<a href="http://www.sun.ac.za/"> UNIVERSITY OF STELLENBOSCH  </a> ','<a href="http://www.up.ac.za/"> UNIVERSITY OF PRETORIA </a> ','<a href="http://www.uknz.ac.za/"> UNIVERSITY OF KWAZULU-NATAL  </a> ','<a href="http://www.uwc.ac.za/"> UNIVERSITY OF WESTERN CAPE  </a> ','<a href="https://www.wits.ac.za/"> UNIVERSITY OF WITWATERSTRAND  </a> ');

        $CareerTitleC = "Nurse";
        $UniveristyLinkC = array('<a href="https://www.wits.ac.za/"> University of Witwatersrand  </a> ','<a href="http://www.students.uct.ac.za/"> University of Cape Town  </a> ','<a href="https://www.up.ac.za/"> University of Pretoria  </a> ','<a href="https://www.tut.ac.za/"> Tshwane University of Technology  </a> ','<a href="https://www.vut.ac.za/"> Vaal University of Technology  </a> ', '<a href="https://www.cput.ac.za/"> Cape Peninsula University of Technology </a> ', '<a href="https://www.ufh.ac.za/"> University of Fort Hare  </a> ');
    }
    else if(max($OppennessPecentage,$ConscientiousnessPecentage,$AgreeablePecentage,$ExtroversionPecentage,$ExtroversionPecentage,$NeuroticismPecentage) == $ExtroversionPecentage){
        $PersonalityScore = "Extroversion";
        $PersonalityScoreMoreData = "You show Sociability, Talkative, Outgoing";
        $CareersPersonality = array('Event planning','Counselor','Social work','Teaching','Human Resources','Flight attendant', 'Law ', 'Acting');
    
        $CareerTitleA = "Teaching";
        $UniveristyLinkA = array('<a href="http://www.uj.ac.za/"> UNIVERSITY OF JOHANNESBURG  </a> ','<a href="http://www.sun.ac.za/ "> UNIVERSITY OF STELLENBOSCH  </a> ','<a href="http://www.uknz.ac.za/"> UNIVERSITY OF KWAZULU-NATAL </a> ','<a href="http://www.uwc.ac.za/"> UNIVERSITY OF WESTERN  </a> ','<a href="http://www.up.ac.za/"> UNIVERSITY OF PRETORIA  </a> ');
        
        $CareerTitleB = "Human Resources";
        $UniveristyLinkB = array('<a href="http://www.up.ac.za/"> University of Pretoria  </a> ','<a href="http://www.sun.ac.za/"> Stellenbosch University  </a> ','<a href="http://www.uj.ac.za/"> University of Johannesburg  </a> ','<a href="http://www.students.uct.ac.za/"> University of Cape Town  </a> ','<a href="http://www.tut.ac.za/"> Tshwane university of Technology  </a> ');

        $CareerTitleC = "Acting";
        $UniveristyLinkC = array('<a href="http://www.tut.ac.za/"> Tshwane university of Technology  </a> ','<a href="http://www.uct.ac.za/"> University of Cape Town  </a> ','<a href="http://www.ru.ac.za/"> Rhodes University  </a> ','<a href="https://www.wits.ac.za/"> University of Witwatersrand  </a> ','<a href="http://www.up.ac.za/"> University of Pretoria  </a> ');

    
    }
    else if(max($OppennessPecentage,$ConscientiousnessPecentage,$AgreeablePecentage,$ExtroversionPecentage,$ExtroversionPecentage,$NeuroticismPecentage) == $NeuroticismPecentage){
        $PersonalityScore = "Neuroticism";
        $PersonalityScoreMoreData = "You show Sadness, Moodiness and Emotional instability";
        $CareersPersonality = array('Accountant','Editor','IT','Mechanic','Engineering','Writer','Artist');

        $CareerTitleA = "IT";
        $UniveristyLinkA = array('<a href="https://www.tut.ac.za/"> Tshwane University of Technology  </a> ','<a href="https://www.up.ac.za/"> University of Pretoria  </a> ','<a href="http://www.sun.ac.za/"> Stellenbosch University  </a> ','<a href="http://www.uct.ac.za/"> University of Cape Town  </a> ','<a href="http://www.ru.ac.za/"> Rhodes University  </a> ','<a href="http://www.nwu.ac.za/"> Northwest University  </a> ','<a href="Nelson Mandela University "> http://www.nmu.ac.za/ </a> ','<a href="https://www.ukzn.ac.za/"> University of KwaZulu-Natal </a> ');
        
        $CareerTitleB = "Engineering";
        $UniveristyLinkB = array('<a href="http://www.uj.ac.za/"> University of Johannesburg  </a> ','<a href="https://www.tut.ac.za/"> Tshwane University of Technology </a> ','<a href="https://www.up.ac.za/"> University of Pretoria  </a> ','<a href="">  </a> ','<a href="http://www.sun.ac.za/"> Stellenbosch University  </a> ','<a href="http://www.uct.ac.za/"> University of Cape Town  </a> ','<a href="http://www.unisa.ac.za/"> University of South Africa  </a> ','<a href="http://www.nwu.ac.za/"> Northwest University </a> ');

        $CareerTitleC = "Accounting";
        $UniveristyLinkC = array('<a href="https://www.up.ac.za/"> University of Pretoria </a> ','<a href="http://www.uj.ac.za/"> University of Johannesburg  </a> ','<a href="https://www.tut.ac.za/"> Tshwane University of Technology  </a> ','<a href="https://www.up.ac.za/"> University of Pretoria  </a> ','<a href="http://www.sun.ac.za/"> Stellenbosch University </a> ','<a href="http://www.unisa.ac.za/"> University of South Africa  </a> ','<a href="http://www.uct.ac.za/"> University of Cape Town  </a> ','<a href="http://www.nwu.ac.za/"> Northwest University  </a> ');
    } 
    //Check if results exist exist
    if(selectAllData($conn,'useranswer','Username','Username',$_SESSION['email']) == true){
        $displayResults = "";
        $mainDisplayOfResults = "";
        $resultsLink = "";
        $btnTestStart = "none";
        $testLink = "none";
    }else{
        $resultsLink = "none";
    }
    

}
//Registering users
if(isset($_POST['btnRegisterUsers'])){

    //Check if a user exist testting the ssystem of this nature 
    if(selectAllData($conn,'user','UserName','UserName',$_POST['email']) == $_POST['email']){
        //___________________________User exit 
        $alertUserExist = "";

    }else{
        //___________________________Insert User
        insertUsers($conn, $_POST['name'],$_POST['surname'], $_POST['id_No'], $_POST['cell_No'], $_POST['email'], $_POST['password'], $_POST['branch']);
        $alertUserCreated = "";
    }
}
//__________________________________________________________________
//Logout btn
if(isset($_GET['logout'])){
   
    session_destroy();
    header('Location:./index.php');
}

//main dashbord processing run here
if(isset($_SESSION['email'])){
    //Activate all the bodys of the elements
    $mainSectionElement = ""; 

}else{
    //Make no process can run if the session is not active
    $sessionExpireElement = "";   
}