<?php
    @session_start();

    //All variables should be here
    //__________________________________________________________________________________________
    
    //Login var logout div
    $loginDiv = "";
    $logOutDv = "none";
    $loginDivSession = "none";

    $alertEmailError = "none";
    $alertPassError = "none";
    $alertUserCreated  = "none";
    $alertUserExist = "none";
    $alertUserUpdated = "none";

    //Show results and test when logged in to the system
    $resultsLink = "none";
    $testLink = "none";
    
    //Buttons b4 loginDivSession
    $btnTestStart = "none";
    $btnLoginMain = "";

    //Alerts variables
    $updateProfileSuccess = "none";

    //Test variables
    $testDivHide = "none";
    $testDivShow = "";


    //Results counting variables
    $OppennessCount = 0;
    $OppennessTotalCount = 0;
    $OppennessPecentage = 0;

    $ConscientiousnessCount = 0;
    $ConscientiousnessTotalCount = 0;
    $ConscientiousnessPecentage = 0;

    $AgreeableCount = 0;
    $AgreeableTotalCount = 0;
    $AgreeablePecentage = 0;

    $ExtroversionCount = 0;
    $ExtroversionTotalCount = 0;
    $ExtroversionPecentage = 0;

    $NeuroticismCount = 0;
    $NeuroticismTotalCount = 0;
    $NeuroticismPecentage = 0;
    $TotalScore  = 0;
    $PersonalityScore = "None";
    $PersonalityScoreMoreData = "None";


    //-------------------------
    $adminUpdateRecordAlert = "none";
    $adminDeleteRecordAlert = "none";

    $systemActive = "none";
    $displaySessionOver = "none";
    //________________________________________________________________
    $addQuestionAlert = "none";
    //__________________________________________________________________________________________
    //Login and log out with alerts

    //___________________________________________________________________________________________
    if(isset($_SESSION['email'])){

        //Variable (Login var logout div when a session is active)
        $loginDiv = "none";
        $logOutDv = "";
        $loginDivSession = "";

        //Results and test  (Login var logout div when a session is active)
        $resultsLink = "";
        $testLink = "";

        //Buttons b4 loginDivSession (Login Session)
        $btnTestStart = "";
        $btnLoginMain = "none";
    }
    //
    $displayResults = "none";
    $mainDisplayOfResults = "none";

    $displayAdminUserResults = "none";
    $displayAdminUserResultsNone = "none";

    //Admin information
    $alertAdminInfoUpdate = "none";

    /////////////////////////
    $CareerTitleA = "";